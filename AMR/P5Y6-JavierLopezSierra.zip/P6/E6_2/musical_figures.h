#ifndef FIGURES_H
#define FIGURES_H

#define R 4000 //Redonda a 4000ms
#define B 2000 //Blanca a 2000ms
#define N 1000 //Negra a 1000ms
#define C 500 //Corchea a 500ms
#define S 250 //Semicorchea a 250ms
#define F 125 //Fusa a 125ms
#define T 62 //Semifusa a 62ms

#endif //FIGURES_H